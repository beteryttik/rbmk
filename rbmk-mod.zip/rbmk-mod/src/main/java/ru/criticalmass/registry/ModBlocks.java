package ru.criticalmass.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.criticalmass.RbmkMod;
import ru.criticalmass.content.decor.GratedBlock;
import ru.criticalmass.content.decor.HazardBlock;
import ru.criticalmass.content.decor.SteelFramedBlock;
import ru.criticalmass.content.reactor.ControlRodBlock;
import ru.criticalmass.content.reactor.ControlRodDriveBlock;
import ru.criticalmass.content.reactor.ReactorCoreBlock;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RbmkMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RbmkMod.MODID);

    public static final DeferredBlock<Block> CONCRETE_WHITE = registerBlock("concrete_white", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_WHITE = registerBlock("concrete_bricks_white", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_WHITE = registerBlock("concrete_tiles_white", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_LIGHT_GRAY = registerBlock("concrete_light_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_LIGHT_GRAY = registerBlock("concrete_bricks_light_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_LIGHT_GRAY = registerBlock("concrete_tiles_light_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_GRAY = registerBlock("concrete_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_GRAY = registerBlock("concrete_bricks_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_GRAY = registerBlock("concrete_tiles_gray", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BLACK = registerBlock("concrete_black", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_BLACK = registerBlock("concrete_bricks_black", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_BLACK = registerBlock("concrete_tiles_black", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_RED = registerBlock("concrete_red", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_RED = registerBlock("concrete_bricks_red", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_RED = registerBlock("concrete_tiles_red", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BLUE = registerBlock("concrete_blue", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_BLUE = registerBlock("concrete_bricks_blue", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_BLUE = registerBlock("concrete_tiles_blue", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_GREEN = registerBlock("concrete_green", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_GREEN = registerBlock("concrete_bricks_green", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_GREEN = registerBlock("concrete_tiles_green", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_YELLOW = registerBlock("concrete_yellow", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_BRICKS_YELLOW = registerBlock("concrete_bricks_yellow", Block::new, "STONE");
    public static final DeferredBlock<Block> CONCRETE_TILES_YELLOW = registerBlock("concrete_tiles_yellow", Block::new, "STONE");
    public static final DeferredBlock<Block> HAZARD_BLACK_YELLOW = registerBlock("hazard_black_yellow", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> HAZARD_YELLOW_BLACK = registerBlock("hazard_yellow_black", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> HAZARD_RED_WHITE = registerBlock("hazard_red_white", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> HAZARD_WHITE_RED = registerBlock("hazard_white_red", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> HAZARD_GREEN_WHITE = registerBlock("hazard_green_white", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> HAZARD_BLUE_WHITE = registerBlock("hazard_blue_white", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> GRAPHITE_BLOCK = registerBlock("graphite_block", Block::new, "STONE");
    public static final DeferredBlock<Block> GRAPHITE_BRICKS = registerBlock("graphite_bricks", Block::new, "STONE");
    public static final DeferredBlock<Block> GRAPHITE_CRACKED = registerBlock("graphite_cracked", Block::new, "STONE");
    public static final DeferredBlock<Block> GRAPHITE_POLISHED = registerBlock("graphite_polished", Block::new, "STONE");
    public static final DeferredBlock<Block> LEAD_BLOCK = registerBlock("lead_block", Block::new, "METAL");
    public static final DeferredBlock<Block> LEAD_BRICKS = registerBlock("lead_bricks", Block::new, "METAL");
    public static final DeferredBlock<Block> LEAD_SHIELDED = registerBlock("lead_shielded", Block::new, "METAL");
    public static final DeferredBlock<Block> STEEL_BLOCK = registerBlock("steel_block", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> STEEL_BRICKS = registerBlock("steel_bricks", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> STEEL_RUSTY = registerBlock("steel_rusty", Block::new, "METAL");
    public static final DeferredBlock<Block> STEEL_DARK = registerBlock("steel_dark", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> PIPE_IRON = registerBlock("pipe_iron", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_STEEL = registerBlock("pipe_steel", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_COPPER = registerBlock("pipe_copper", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_LEAD = registerBlock("pipe_lead", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_INSULATED = registerBlock("pipe_insulated", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_LARGE = registerBlock("pipe_large", Block::new, "METAL");
    public static final DeferredBlock<Block> PIPE_THIN = registerBlock("pipe_thin", Block::new, "METAL");
    public static final DeferredBlock<Block> VALVE_RED = registerBlock("valve_red", Block::new, "METAL");
    public static final DeferredBlock<Block> VALVE_GREEN = registerBlock("valve_green", Block::new, "METAL");
    public static final DeferredBlock<Block> VALVE_YELLOW = registerBlock("valve_yellow", Block::new, "METAL");
    public static final DeferredBlock<Block> LAMP_WHITE = registerBlock("lamp_white", Block::new, "GLASS");
    public static final DeferredBlock<Block> LAMP_YELLOW = registerBlock("lamp_yellow", Block::new, "GLASS");
    public static final DeferredBlock<Block> LAMP_RED = registerBlock("lamp_red", Block::new, "GLASS");
    public static final DeferredBlock<Block> LAMP_GREEN = registerBlock("lamp_green", Block::new, "GLASS");
    public static final DeferredBlock<Block> LAMP_BLUE = registerBlock("lamp_blue", Block::new, "GLASS");
    public static final DeferredBlock<Block> LAMP_EMERGENCY = registerBlock("lamp_emergency", Block::new, "GLASS");
    public static final DeferredBlock<Block> TURBINE_CASING = registerBlock("turbine_casing", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> GENERATOR_CASING = registerBlock("generator_casing", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> CONDENSER_CASING = registerBlock("condenser_casing", Block::new, "METAL");
    public static final DeferredBlock<Block> COOLANT_INTAKE = registerBlock("coolant_intake", Block::new, "METAL");
    public static final DeferredBlock<Block> COOLANT_PORT = registerBlock("coolant_port", Block::new, "METAL");
    public static final DeferredBlock<Block> STEAM_OUTLET = registerBlock("steam_outlet", Block::new, "METAL");
    public static final DeferredBlock<Block> REACTOR_HOUSING = registerBlock("reactor_housing", ReactorCoreBlock::new, "METAL");
    public static final DeferredBlock<Block> REACTOR_WINDOW = registerBlock("reactor_window", Block::new, "METAL");
    public static final DeferredBlock<Block> FUEL_ROD_STANDS = registerBlock("fuel_rod_stands", Block::new, "METAL");
    public static final DeferredBlock<Block> CONTROL_ROD_DRIVE = registerBlock("control_rod_drive", ControlRodDriveBlock::new, "METAL");
    public static final DeferredBlock<Block> CONTROL_ROD_CHANNEL = registerBlock("control_rod_channel", ControlRodBlock::new, "METAL");
    public static final DeferredBlock<Block> PUMP_CASING = registerBlock("pump_casing", Block::new, "METAL");
    public static final DeferredBlock<Block> SIGN_RADIATION = registerBlock("sign_radiation", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_DANGER_HIGH_VOLTAGE = registerBlock("sign_danger_high_voltage", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_NO_ENTRY = registerBlock("sign_no_entry", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_EXIT = registerBlock("sign_exit", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_BIOSAFETY = registerBlock("sign_biosafety", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_WARNING_GENERAL = registerBlock("sign_warning_general", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_CHEMICAL = registerBlock("sign_chemical", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> SIGN_AUTHORIZATION = registerBlock("sign_authorization", HazardBlock::new, "METAL");
    public static final DeferredBlock<Block> FLOOR_GRATE = registerBlock("floor_grate", GratedBlock::new, "METAL");
    public static final DeferredBlock<Block> VENT_COVER = registerBlock("vent_cover", GratedBlock::new, "METAL");
    public static final DeferredBlock<Block> CABLE_TRAY = registerBlock("cable_tray", Block::new, "METAL");
    public static final DeferredBlock<Block> JUNCTION_BOX = registerBlock("junction_box", Block::new, "METAL");
    public static final DeferredBlock<Block> SCAFFOLDING_BLOCK = registerBlock("scaffolding_block", Block::new, "METAL");
    public static final DeferredBlock<Block> GRATING_DARK = registerBlock("grating_dark", GratedBlock::new, "METAL");
    public static final DeferredBlock<Block> BLAST_DOOR = registerBlock("blast_door", Block::new, "METAL");
    public static final DeferredBlock<Block> REINFORCED_GLASS = registerBlock("reinforced_glass", Block::new, "METAL");
    public static final DeferredBlock<Block> MACHINE_FRAME = registerBlock("machine_frame", SteelFramedBlock::new, "METAL");
    public static final DeferredBlock<Block> FAN_UNIT = registerBlock("fan_unit", Block::new, "METAL");
    public static final DeferredBlock<Block> FILTER_UNIT = registerBlock("filter_unit", Block::new, "METAL");
    public static final DeferredBlock<Block> CONTROL_DESK = registerBlock("control_desk", Block::new, "METAL");
    public static final DeferredBlock<Block> CONTROL_DESK_TERMINAL = registerBlock("control_desk_terminal", Block::new, "METAL");
    public static final DeferredBlock<Block> PUMP_STATION_FRAME = registerBlock("pump_station_frame", Block::new, "METAL");
    public static final DeferredBlock<Block> LADDER_METAL = registerBlock("ladder_metal", Block::new, "METAL");
    public static final DeferredBlock<Block> LOCKER_RED = registerBlock("locker_red", Block::new, "METAL");
    public static final DeferredBlock<Block> LOCKER_YELLOW = registerBlock("locker_yellow", Block::new, "METAL");
    public static final DeferredBlock<Block> LOCKER_GREEN = registerBlock("locker_green", Block::new, "METAL");
    public static final DeferredBlock<Block> FILING_CABINET = registerBlock("filing_cabinet", Block::new, "METAL");
    public static final DeferredBlock<Block> BENCH_METAL = registerBlock("bench_metal", Block::new, "METAL");
    public static final DeferredBlock<Block> TABLE_LAB = registerBlock("table_lab", Block::new, "METAL");

    private static DeferredBlock<Block> registerBlock(String name, Supplier<Block> supplier, String sound) {
        BlockBehaviour.Properties props = BlockBehaviour.Properties.of()
                .strength(2.0f, 6.0f)
                .sound(SoundType.valueOf(sound));
        DeferredBlock<Block> block = BLOCKS.register(name, supplier);
        ITEMS.registerSimpleBlockItem(name, block);
        return block;
    }

    public static String id(String path) {
        return RbmkMod.MODID + ":" + path;
    }
}
