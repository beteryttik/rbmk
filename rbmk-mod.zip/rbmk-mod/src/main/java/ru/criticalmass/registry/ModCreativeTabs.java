package ru.criticalmass.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.criticalmass.RbmkMod;

import java.util.function.Supplier;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RbmkMod.MODID);

    public static final Supplier<CreativeModeTab> RBMK_TAB = TABS.register("rbmk_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rbmk"))
                    .icon(() -> ModBlocks.GRAPHITE_BLOCK.get().asItem().getDefaultInstance())
                    .displayItems((params, output) -> {
                        for (DeferredBlock<Block> b : ModBlocks.BLOCKS.getEntries()) {
                            output.accept(b.get());
                        }
                    })
                    .build());
}
